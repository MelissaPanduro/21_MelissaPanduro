/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistema.empleadosDAL;

import com.sun.jdi.connect.spi.Connection;

/**
 *
 * @author Melissa
 */
public class conexion {
    String strConexionDB="jdbc:sqlite:C:/Users/Melisa/Documents/db/sistema.s3db";
    Connection conn= null;
    
    public conexion(){
        try {
            Class.forName("org.sqlite,JDBC");
            conn= DriverManager.getConnection(strConexionDB);
            
            System.out.println("Conexión establecida");
            
            } catch (Exception e){
                
                System.out.println("Error de conexión"+e);
        }
    }
}
